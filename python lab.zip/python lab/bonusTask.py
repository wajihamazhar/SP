import calendar

print(calendar.month(2018,4))
