num = input("Enter number: ")

dict1 = {}

for i in range(1 , num+1):
	dict1[i] = i*i

print dict1
