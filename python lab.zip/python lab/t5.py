num = raw_input("Enter sentence: ")

str2 = '' 
for i in range(0 , len(num)):
	
	str2 += num[i].upper()

print str2

