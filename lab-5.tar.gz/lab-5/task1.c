#include <stdio.h>
#include <unistd.h>
int main(){
	printf("Real user-ID : %d\n", (long)getuid());
	printf("Effective user-ID : %d\n", (long)geteuid());
	printf("Real group-ID : %d\n", (long)getgid());
	printf("Effective group-ID : %d\n", (long)getegid());
	return 0;
}
