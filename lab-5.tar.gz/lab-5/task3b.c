#include <stdio.h>
#include<sys/wait.h>
#include <unistd.h>
int main()
{
	int cpid=-1;
	int status=0;
	cpid=fork();
	if(cpid==-1)
	{

		printf("Fork Failed...");
		exit(0);
	}
	
	if(cpid==0)
	{
		exit(-1);
	}
	else
	{
		wait(&status);
		printf("Exit status = %d\n",WEXITSTATUS(status));

	}
  return(0);
}

