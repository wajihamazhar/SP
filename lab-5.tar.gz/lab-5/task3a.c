#include <stdio.h>
#include <unistd.h>
int main()
{
	int cpid=-1;
	cpid=fork();
	if(cpid==-1)
	{

		printf("Fork Failed...");
		exit(0);
	}
	
	if(cpid==0)
	{
		printf("\nChild PID : %d" , (long)getpid() );
		printf("\nChild PPID : %d" , (long)getppid() );
	}
	else
	{
		printf("\nParent PID : %d" , (long)getpid() );
		printf("\nParent PPID : %d" , (long)getppid() );
	}
  return(0);
}

