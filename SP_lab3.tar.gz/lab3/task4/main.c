#include<stdio.h>
#include<stdlib.h>
//#include "myMath.h"
void main()
{
	int a=0;
	int b=0;
	printf("Enter num1 : ");
	scanf("%d",&a);
	printf("Enter num2 : ");
	scanf("%d",&b);
	int c = isEqual(a,b);
	if(c == 1)
	{
		printf("Num1 and Num2 are equal...");
	}
	else
	{
		printf("Num1 and Num2 are not equal...");
	}
	swap(a,b);
}

