#include<stdio.h>
#include<stdlib.h>
#include "myStr.h"

void main()
{
	int a=6;
	char arr[6] = {'a', 'b' ,'b' ,'c' , 'b' , 'a'};
	int res = isPalindrom(arr,a);
	if(res == 1)
	{
		printf(" It is Palindrom ");
	}
	else
	{ 
		printf(" It is not Palindrom\n ");
	}

}

