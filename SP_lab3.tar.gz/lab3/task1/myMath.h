int isEqual(int a, int b);
int swap(int a, int b);
