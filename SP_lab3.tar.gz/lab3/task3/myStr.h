int isPalindrom( char *arr, int size);
