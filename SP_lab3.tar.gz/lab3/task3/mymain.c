#include<stdio.h>
#include<stdlib.h>
#include "myStr.h"
#include "myMath.h"

void main()
{

	int a=0;
	int b=0;
	printf("Enter num1 : ");
	scanf("%d",&a);
	printf("Enter num2 : ");
	scanf("%d",&b);
	int c = isEqual(a,b);
	if(c == 1)
	{
		printf("Num1 and Num2 are equal...");
	}
	else
	{
		printf("Num1 and Num2 are not equal...");
	}
	swap(a,b);

		

	char arr[6] = {'a', 'b' ,'b' ,'c' , 'b' , 'a'};
	int res = isPalindrom(arr,6);
	if(res == 1)
	{
		printf("\nIt is Palindrom ");
	}
	else
	{ 
		printf("\nIt is not Palindrom\n ");
	}
}

