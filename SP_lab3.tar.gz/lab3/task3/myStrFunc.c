#include<stdlib.h>
#include<stdio.h>
int isPalindrom( char *arr, int size)
{
	int flag=1;
	int en = size - 1;
	int st = 0; 
	while( en > 0)
	{	
		if(arr[st] == arr[en])
		{
			
			flag=1;
		}
		else
		{
			flag = -1;
			break;

		}
		en--;
		st++;
		
		
	}

	return flag;	
}
