from numpy import *
import numpy as np

def Search(List = []):
	arr = array([[1,2,3,4,5,6,7,8],
	     	    [9,10,11,12,13,14,15,16],
		    [17,18,19,20,21,22,23,24],
		    [25,26,27,28,29,30,31,32],
		    [33,34,35,36,37,38,39,40],
		    [41,42,43,44,45,46,47,48],
		    [49,50,51,52,53,54,55,56],	
	     	    [57,58,59,60,61,62,63,64]])
	
	a0 = (arr[:2,[0,1]])
	if (a0==List).all():
		print "Matrix Found At Index..." , 0
		return
	
	
	a1 = (arr[:2,[1,2]])
	if (a1==List).all():
		print "Matrix Found At Index..." , 1
		return

	a2 = (arr[:2,[2,3]])
	if (a2==List).all():
		print "Matrix Found At Index..." , 2
		return

	a3 = (arr[:2,[3,4]])
	if (a3==List).all():
		print "Matrix Found At Index..." , 3
		return

	a4 = (arr[:2,[4,5]])
	if (a4==List).all():
		print "Matrix Found At Index..." , 4
		return

	a5 = (arr[:2,[5,6]])
	if (a5==List).all():
		print "Matrix Found At Index..." , 5
		return

	a6 = (arr[:2,[6,7]])
	if (a6==List).all():
		print "Matrix Found At Index..." , 6
		return

	
	

	a8 = (arr[1:3,[0,1]])
	if (a8==List).all():
		print "Matrix Found At Index..." , 8
		return

	a9 = (arr[1:3,[1,2]])
	if (a9==List).all():
		print "Matrix Found At Index..." , 9
		return

	a10 = (arr[1:3,[2,3]])
	if (a10==List).all():
		print "Matrix Found At Index..." , 10
		return

	a11 = (arr[1:3,[3,4]])
	if (a11==List).all():
		print "Matrix Found At Index..." , 11
		return

	a12 = (arr[1:3,[4,5]])
	if (a12==List).all():
		print "Matrix Found At Index..." , 12
		return

	a13 = (arr[1:3,[5,6]])
	if (a13==List).all():
		print "Matrix Found At Index..." , 13
		return

	a14 = (arr[1:3,[6,7]])
	if (a14==List).all():
		print "Matrix Found At Index..." , 14
		return
	
	
	a16 = (arr[2:4,[0,1]])
	if (a16==List).all():
		print "Matrix Found At Index..." , 16
		return


	a17 = (arr[2:4,[1,2]])
	if (a17==List).all():
		print "Matrix Found At Index..." , 17
		return

	a18 = (arr[2:4,[2,3]])
	if (a18==List).all():
		print "Matrix Found At Index..." , 18
		return

	a19 = (arr[2:4,[3,4]])
	if (a19==List).all():
		print "Matrix Found At Index..." , 19
		return

	a20 = (arr[2:4,[4,5]])
	if (a20==List).all():
		print "Matrix Found At Index..." , 20
		return

	a21 = (arr[2:4,[5,6]])
	if (a21==List).all():
		print "Matrix Found At Index..." , 21
		return

	a22 = (arr[2:4,[6,7]])
	if (a22==List).all():
		print "Matrix Found At Index..." , 22
		return
	

	a24 = (arr[3:5,[0,1]])
	if (a24==List).all():
		print "Matrix Found At Index..." , 24
		return


	a25 = (arr[3:5,[1,2]])
	if (a25==List).all():
		print "Matrix Found At Index..." , 25
		return

	a26 = (arr[3:5,[2,3]])
	if (a26==List).all():
		print "Matrix Found At Index..." , 26
		return

	a27 = (arr[3:5,[3,4]])
	if (a27==List).all():
		print "Matrix Found At Index..." , 27
		return

	a28 = (arr[3:5,[4,5]])
	if (a28==List).all():
		print "Matrix Found At Index..." , 28
		return

	a29 = (arr[3:5,[5,6]])
	if (a29==List).all():
		print "Matrix Found At Index..." , 29
		return

	a30 = (arr[3:5,[6,7]])
	if (a30==List).all():
		print "Matrix Found At Index..." , 30
		return
	

	a32 = (arr[4:6,[0,1]])
	if (a32==List).all():
		print "Matrix Found At Index..." , 32
		return

	a33 = (arr[4:6,[1,2]])
	if (a33==List).all():
		print "Matrix Found At Index..." , 33
		return

	a34 = (arr[4:6,[2,3]])
	if (a34==List).all():
		print "Matrix Found At Index..." , 34
		return

	a35 = (arr[4:6,[3,4]])
	if (a35==List).all():
		print "Matrix Found At Index..." , 35
		return

	a36 = (arr[4:6,[4,5]])
	if (a36==List).all():
		print "Matrix Found At Index..." , 36
		return
	

	a37 = (arr[4:6,[5,6]])
	if (a37==List).all():
		print "Matrix Found At Index..." , 37
		return

	a38 = (arr[4:6,[6,7]])
	if (a38==List).all():
		print "Matrix Found At Index..." , 0
		return
	
	

	a40 = (arr[5:7,[0,1]])
	if (a40==List).all():
		print "Matrix Found At Index..." , 40
		return

	a41 = (arr[5:7,[1,2]])
	if (a41==List).all():
		print "Matrix Found At Index..." , 41
		return

	a42 = (arr[5:7,[2,3]])
	if (a42==List).all():
		print "Matrix Found At Index..." , 42
		return

	a43 = (arr[5:7,[3,4]])
	if (a43==List).all():
		print "Matrix Found At Index..." , 43
		return

	a44 = (arr[5:7,[4,5]])
	if (a44==List).all():
		print "Matrix Found At Index..." , 44
		return
	
	a45 = (arr[5:7,[5,6]])
	if (a45==List).all():
		print "Matrix Found At Index..." , 45
		return

	a46 = (arr[5:7,[6,7]])
	if (a46==List).all():
		print "Matrix Found At Index..." , 46
		return

	
	a48 = (arr[6:8,[0,1]])
	if (a48==List).all():
		print "Matrix Found At Index..." , 48
		return

	a49 = (arr[6:8,[1,2]])
	if (a49==List).all():
		print "Matrix Found At Index..." , 49
		return

	a50 = (arr[6:8,[2,3]])
	if (a50==List).all():
		print "Matrix Found At Index..." , 50
		return

	a51 = (arr[6:8,[3,4]])
	if (a51==List).all():
		print "Matrix Found At Index..." , 51
		return

	a52 = (arr[6:8,[4,5]])
	if (a52==List).all():
		print "Matrix Found At Index..." , 52
		return

	a53 = (arr[6:8,[5,6]])
	if (a53==List).all():
		print "Matrix Found At Index..." , 53
		return

	a54 = (arr[6:8,[6,7]])
	if (a54==List).all():
		print "Matrix Found At Index..." , 54
		return

	else:
		print "Not Found..."
		
	

def InputMatrix():
	list1=[]
	list2=[]
	num_array=[]
	print "Enter Row1:"
	for i in range(0,2):
		a=input()
		list1.append(a)
	print "Enter Row1:"
	for i in range(0,2):
		a=input()
		list2.append(a)
	num_array.append(list1)
	num_array.append(list2)
	my_array = np.asarray(num_array)
	Search(my_array)

InputMatrix()

















