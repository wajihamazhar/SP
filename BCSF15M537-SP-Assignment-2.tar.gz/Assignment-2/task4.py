import sys
import os
import psutil
import datetime
def pids_info(pid):
   	
	list1=[]
	f=open('task1.py','r')
	process=psutil.Process(pid)
	parent = process.ppid()
	process1=psutil.Process(parent)
	print process.as_dict(attrs=['pid'])
	print process.as_dict(attrs=['name'])			
	print process1.as_dict(attrs=['ppid'])
	print process1.as_dict(attrs=['name'])
	ct = datetime.datetime.fromtimestamp(process.create_time())
    	print("create_time from psutil: {}".format(ct))
	p=psutil.Process()
	print p.open_files()
	print process.open_files()
	print process.memory_info()
	

def main():
	arguments = len(sys.argv)
	for arg in sys.argv[1:]:
		pids_info(int(arg))	

if __name__ == "__main__":
	main()


	   
