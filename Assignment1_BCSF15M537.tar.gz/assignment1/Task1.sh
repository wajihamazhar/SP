#!/bin/bash

#TASK 1

# Directory already exist or not
test -d Txt
var=`echo $?`
if [ $var -ne 0  ]
then 
	mkdir Txt      
fi


test -d Doc
var1=`echo $?`
if [ $var1 -ne 0  ]
then 
	mkdir Doc     
fi

test -d Csv
var2=`echo $?`
if [ $var2 -ne 0  ]
then 
	mkdir Csv     
fi

test -d Mp3
var3=`echo $?`
if [ $var3 -ne 0  ]
then 
	mkdir Mp3    
fi

test -d Mp4
var4=`echo $?`
if [ $var4 -ne 0  ]
then 
	mkdir Mp4     
fi


#Saving files to arrays

txt1=(`ls *.txt`)
doc1=(`ls *.doc`)
csv1=(`ls *.csv`)
mp31=(`ls *.mp3`)
mp41=(`ls *.mp4`)



#moving files to directories
c1=${#txt1[*]}
if [ $c1 -ne 0 ]
then
	for i in `seq 0 $c1`
	do 
		mv -f ${txt1[i]} Txt 
	done
fi



c2=${#doc1[*]}
if [ $c2 -ne 0 ]
then
	for i in `seq 0 $c2`
	do 
		mv -f ${doc1[i]} Doc
	done
fi

c3=${#csv1[*]}
if [ $c3 -ne 0 ]
then
	for i in `seq 0 $c3`
	do 
		mv -f ${csv1[i]} Csv
	done
fi


c4=${#mp31[*]}
if [ $c4 -ne 0 ]
then
	for i in `seq 0 $c4`
	do 
		mv -f ${mp31[i]} Mp3
	done
fi


c5=${#mp41[*]}
if [ $c5 -ne 0 ]
then
	for i in `seq 0 $c5`
	do 
		mv -f ${mp41[i]} Mp4
	done
fi



#List Directories
echo -e "\n Text Files:"
ls Txt

echo -e "\n Doc Files:"
ls Doc

echo -e "\n Csv Files:"
ls Csv

echo -e "\n Mp3 Files:"
ls Mp3

echo -e "\n Mp4 Files:"
ls Mp4




















