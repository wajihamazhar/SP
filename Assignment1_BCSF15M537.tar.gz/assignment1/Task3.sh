#!/bin/bash

#TASK 3

Is_lower()
{

	echo "Enter string to convert into lower case:"
	while IFS=" " 
		read var
		 do 
			echo "var=$var";
			break
	done
	var=${var,,}
	echo -e "\nString in lower case:"
	echo $var
}

Is_root()
{
	var=`whoami`
	var1=`id -u $var`
	var2=`id -u root`
	
	if [ $var1 -eq $var2 ]
	then
		echo -e "\nScript is executed by root..."
	else
		echo -e "\nScript is executed by normal user..."
	fi 
}

Is_user_exists()
{
	echo -e "\nEnter Username:"
	read  user
	array=(`cat /etc/passwd | grep $user`)
	num=`echo ${#array[@]}`
	
	if [ $num -eq 0 ]
	then
		echo -e "\n$user not exist ..."
	else
		echo -e "\n$user exist..."
	fi
	
	
}

Is_lower
Is_root
Is_user_exists











