#!/bin/bash

#TASK 4

echo "Enter File name:"
read filename


#File not exist
test -f $filename
var=`echo $?`
if [ $var -ne 0  ]
then 
	echo "File not found..."
	exit 0        
fi


#File is empty
test -s $filename
var1=`echo $?`
if [ $var1 -ne 0 ]
then 
	printf "File is empty...\n"
        exit 1
fi


#File found
IFS=$'\r\n' GLOBIGNORE='*' command eval  'file1=($(cat $filename))'

#Sort
echo -e  "\nSorted File:"
IFS=$'\n' sorted=($(sort <<<"${file1[*]}"))
printf "[%s]\n" "${sorted[@]}"

#unique
echo -e "\nFile without duplicate lines:"
IFS=$'\n' unique=($(uniq <<<"${sorted[*]}"))
printf "[%s]\n" "${unique[@]}"


#overwriting the file
echo ' ' > $filename


#Updated File
echo -e "\nUpdated.."
num=${#unique[@]}
for i in `seq 0 $num`
do
  printf "%s\n" "${unique[i]}" | tee -a $filename
done







