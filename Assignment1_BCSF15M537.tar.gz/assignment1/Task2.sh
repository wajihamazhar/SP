#!/bin/bash

# TASK 2

touch evenfile
touch oddfile

#no arguments

if [ $# -eq 0 ]
then
 	echo 'No arguments...'
	exit 0
fi


#File not exist

test -f $1
var=`echo $?`
if [ $var -ne 0  ]
then 
	echo "File not found..."
	exit 0        
fi

#File is empty

test -s $1
var1=`echo $?`
if [ $var1 -ne 0 ]
then 
	printf "File is empty...\n"
        exit 1
fi

#File found

IFS=$'\r\n' GLOBIGNORE='*' command eval  'file1=($(cat $1))'

num=1
num1=${#file1[*]}

#overwriting the file
echo ' ' > evenfile
echo ' ' > oddfile

#Writing to files
for i in `seq 0 $num1`
do 
	check=$((num % 2))
	if [ $check -eq 0 ]
	then
	     printf "%s\n" "${file1[i]}" | tee -a evenfile
	else
	     printf "%s\n" "${file1[i]}" | tee -a oddfile
	fi
	num=`expr $num + 1`
done

echo -e "\n Even File:"
cat evenfile

echo -e "\n Odd File:"
cat oddfile









