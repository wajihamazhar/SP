#include<stdlib.h>
#include<fcntl.h>
#include<stdio.h>

int main(int argc, char *argv[])
{
	char buff[3000];
	int fd = open("/etc/shadow",O_RDONLY,0777);
	int fd1 = open(argv[1],O_CREAT|O_RDRW);
	int n= read(fd,buff,3000);
	int f = write(fd1,buff,n);
	close(fd);
	close(fd1);
	return 0;

	
}
