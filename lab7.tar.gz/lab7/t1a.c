#include<stdlib.h>
#include<fcntl.h>
#include<stdio.h>

int main(int argc, char *argv[])
{
	char buff[255];
	int fd = open(argv[1],O_RDONLY);
	int fd1 = open(argv[2],O_WRONLY);
	int n= read(fd,buff,255);
	int f = write(fd1,buff,n);
	remove(argv[1]);
	close(fd);
	close(fd1);
	return 0;

	
}
