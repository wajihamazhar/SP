#include<stdlib.h>
#include<fcntl.h>
#include<stdio.h>

int main(int argc, char *argv[]){
	char buff[1024];
	int fd1 = open ("Newfile.txt", O_WRONLY);
	while(argc != 0){
		write(fd1, buff, 1);
	}
	
	close(fd1);
    	return 0;
}
